import React from 'react'

const Menu = () => {
  return (
    <div>Menu</div>
  )
}

export default Menu